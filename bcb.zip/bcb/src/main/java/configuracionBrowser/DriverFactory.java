package configuracionBrowser;

import java.io.FileInputStream;
import java.time.Duration;
import java.util.Properties;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.PageFactory;
import pageObjectsManager.LoginPage;
import pageObjectsManager.RegistroVehiculoPage;


public class DriverFactory {
    public static WebDriver driver;
    public static LoginPage loginPage;
    public static RegistroVehiculoPage registroVehiculoPage;

    public  WebDriver getDriver() {
        String url = null;
        try {
            Properties p = new Properties();
            FileInputStream fi = new FileInputStream(Browsers.PROPERTIES);
            p.load(fi);
            url = p.getProperty("Url");
            String browserName = p.getProperty("browser");
            switch (browserName) {

                case "firefox":
                    // code
                    if (null == driver) {
                        System.setProperty("webdriver.gecko.driver", Browsers.GECKO_DRIVER);
                        //DesiredCapabilities capabilities = DesiredCapabilities.firefox();
                        //capabilities.setCapability("PruebaTest", true);
                        driver = new FirefoxDriver();
                        driver.manage().window().maximize();
                    }
                    break;

                case "chrome":
                    // code
                    if (null == driver) {
                        System.setProperty("webdriver.chrome.driver", Browsers.CHROME_DRIVER);
                        // CHROME OPTIONS
                        driver = new ChromeDriver();
                        driver.manage().window().maximize();
                    }
                    break;

                case "ie":
                    // code
                    if (null == driver) {
                        //DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
                       // --System.setProperty("webdriver.ie.driver", Browsers.IE_DRIVER);
                        //capabilities.setCapability("ignoreZoomSetting", true);
                        //driver = new InternetExplorerDriver();
                        //driver.manage().window().maximize();

                        //ChromeOptions chromeOptions = new ChromeOptions();
                        //WebDriverManager.chromedriver().setup();
                        //driver = new ChromeDriver(chromeOptions);

                        //EdgeOptions edgeOptions = new EdgeOptions();
                        //WebDriverManager.edgedriver().setup();
                        //driver = new EdgeDriver(edgeOptions);

                        FirefoxOptions firefoxOptions = new FirefoxOptions();
                        WebDriverManager.firefoxdriver().setup();
                        driver = new FirefoxDriver(firefoxOptions);
                    }
                    break;
            }
        } catch (Exception e) {
            System.out.println("No se puede cargar el navegador: " + e.getMessage());
        } finally {
            assert driver != null;
            //driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
            loginPage = PageFactory.initElements(driver, LoginPage.class);
            registroVehiculoPage = PageFactory.initElements(driver, RegistroVehiculoPage.class);
            driver.get(url);
        }
        return driver;
    }
}
