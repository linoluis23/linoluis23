package configuracionBrowser;

public class Browsers {

    public final static String CONFIG = "properties\\config.properties";

    public final static String GECKO_DRIVER = System.getProperty("user.dir") + "\\src\\test\\java\\browser\\geckodriver.exe";

    public final static String CHROME_DRIVER = System.getProperty("user.dir") + "\\src\\test\\java\\browser\\chromedriver102.exe";

    public final static String IE_DRIVER = System.getProperty("user.dir") + "\\src\\test\\java\\browser\\IEDriverServer.exe";

    public final static String PROPERTIES = System.getProperty("user.dir") + "\\src\\main\\java\\properties\\config.properties";
}
