package stepDefinitions;


import configuracionBrowser.DriverFactory;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RegistroVehiculoSteps extends DriverFactory {
    @Given("^ingresar a pagina url$")
    public void ingresar_a_pagina_url() throws Throwable {
        //Reporter.addStepLog("Accediendo a pagina");
        registroVehiculoPage.paginaPrincipal1();
    }

    @When("^ingresar datos usuario$")
    public void ingresar_datos_usuario() throws Throwable {
        registroVehiculoPage.usuarioContrasenia1("admin");
    }

    @When("^ingresar datos contrasenia$")
    public void ingresar_datos_contrasenia() throws Throwable {
        registroVehiculoPage.usuarioPassword1("admin");
    }

    @When("^hacer click boton ingresar$")
    public void hacer_click_boton_ingresar() throws Throwable {
        registroVehiculoPage.setButtonLogin1();
    }

    @Then("^desplegara pagina dashbord$")
    public void desplegara_pagina_dashbord() throws Throwable {
        registroVehiculoPage.menuPrincipal1();
    }

    @When("^hago click menu vehiculos$")
    public void hago_click_menu_vehiculos() throws Throwable {
        registroVehiculoPage.menu01();
    }

    @When("^click submenu vehiculos$")
    public void click_submenu_vehiculos() throws Throwable {
        registroVehiculoPage.subMenu01();
    }

    @Then("^se desplegara panel productos$")
    public void se_desplegara_panel_productos() throws Throwable {

    }

    @When("^hago click nuevo$")
    public void hago_click_nuevo() throws Throwable {
        registroVehiculoPage.nuevoRegistroVehiculo();
    }

    @Then("^podemos registra un nuevo vehiculo$")
    public void podemos_registra_un_nuevo_vehiculo() throws Throwable {

    }

    @When("^ingreso placa$")
    public void ingreso_placa() throws Throwable {
        registroVehiculoPage.datosPlaca("1210-4v00");
    }

    @When("^ingreso marca$")
    public void ingreso_marca() throws Throwable {
        registroVehiculoPage.datosMarca("TOYOTA");
    }

    @When("^ingreso tipo$")
    public void ingreso_tipo() throws Throwable {
        registroVehiculoPage.datosTipo("CAMION");
    }

    @When("^ingreso modelo$")
    public void ingreso_modelo() throws Throwable {
        registroVehiculoPage.datosModelo("2022");
    }

    @When("^botton registrar$")
    public void botton_registrar() throws Throwable {
        registroVehiculoPage.setButtonRegistrar();
    }

    @Then("^mensaje registro$")
    public void mensaje_registro() throws Throwable {
        registroVehiculoPage.mensajeRegistro();
    }
}
