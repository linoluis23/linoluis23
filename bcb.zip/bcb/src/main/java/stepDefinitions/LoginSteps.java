package stepDefinitions;


import configuracionBrowser.DriverFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps extends DriverFactory {

    @Given("^ingresar a pagina$")
    public void ingresar_a_pagina() throws Throwable {
        //Reporter.addStepLog("Accediendo a pagina");
        loginPage.paginaPrincipal();
    }

    @When("^ingresar usuario \"(.*)\"$")
    public void ingresar_usuario(String user) throws Exception {
        loginPage.usuarioContrasenia(user);
        //loginPage.usuarioPassword("admin");

    }
    @When("^ingresar contrasenia \"(.*)\"$")
    public void ingresar_contrasenia(String pass) throws Exception {
        loginPage.usuarioPassword(pass);

    }

    @And("^hacer click en el boton ingresar$")
    public void hacer_click_en_el_boton_ingresar() throws Throwable {
        loginPage.setButtonLogin();
    }

    @Then("^desplegara pagina principal$")
    public void desplegara_pagina_principal() throws Throwable {
        loginPage.menuPrincipal();
    }
}
