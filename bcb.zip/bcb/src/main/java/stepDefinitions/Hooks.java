package stepDefinitions;


import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import pageObjectsManager.BasePage;
import configuracionBrowser.DriverFactory;

public class Hooks extends DriverFactory {

    @Before
    public void setup() {

        driver = getDriver();

    }

    @After
    public void tearDownAndScreenshotOnFailure(Scenario scenario) {
        try {
            if(driver != null && scenario.isFailed()) {
                BasePage.captureScreenshot();
                driver.manage().deleteAllCookies();
                driver.quit();
                driver = null;
            }
            if(driver != null) {
                driver.manage().deleteAllCookies();
                driver.quit();
                driver = null;
            }
        } catch (Exception e) {
            System.out.println("Los métodos fallaron: tearDownAndScreenshotOnFailure, Exception: " + e.getMessage());
        }
    }
}
