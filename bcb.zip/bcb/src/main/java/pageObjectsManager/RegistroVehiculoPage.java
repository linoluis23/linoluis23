package pageObjectsManager;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class RegistroVehiculoPage extends BasePage{

    public @FindBy(xpath = "//input[@id='usuario']")
    WebElement textUsuario;
    public @FindBy(xpath = "//input[@id='clave']") WebElement textPassword;
    public @FindBy(xpath= "//form[@id='frmLogin']/button") WebElement buttonLogin;
    public @FindBy(linkText = "Vehículos") WebElement menu;
    public @FindBy(xpath = "//a[contains(text(),'Vehiculos')]") WebElement submenu;
    public @FindBy(xpath = "//button[@type='button']") WebElement nuevoRegistro;
    public @FindBy(xpath = "//input[@id='placa']") WebElement textPlaca;
    public @FindBy(xpath = "//select[@id='marca']") WebElement textBoxMarcas;
    public @FindBy(xpath = "//select[@id='tipo']") WebElement textBoxTipos;
    public @FindBy(id = "modelo") WebElement textModelo;
    public @FindBy(xpath = "//button[@id='btnAccion']") WebElement buttonRegistrar;

    public RegistroVehiculoPage() throws IOException {
        super();
    }
    public void paginaPrincipal1()throws IOException{
        //String url;
        getDriver().get("http://localhost/alquiler/");
        new RegistroVehiculoPage();
    }
    public void usuarioContrasenia1(String usuario) throws Exception {
        sendKeysToWebElement(textUsuario,usuario);
        //sendKeysToWebElement(textPassword,password);
    }
    public void usuarioPassword1(String password) throws Exception {
        //sendKeysToWebElement(textUsuario,usuario);
        sendKeysToWebElement(textPassword,password);
    }
    public void setButtonLogin1() throws IOException, InterruptedException {
        waitAndClickElement(buttonLogin);
        new RegistroVehiculoPage();
    }

    public void menuPrincipal1() throws IOException {
        WebElement titulo = getDriver().findElement(By.linkText("Vida Informatico"));
        WaitUntilWebElementIsVisible(titulo);
        Assert.assertEquals("vidainformatico", titulo.getText().toLowerCase().replaceAll("[ ()0-9]", ""));
        new RegistroVehiculoPage();
    }
    public  void menu01() throws IOException, InterruptedException {
        waitAndClickElement(menu);
        new RegistroVehiculoPage();
    }
    public  void subMenu01() throws IOException, InterruptedException {
        waitAndClickElement(submenu);
        new RegistroVehiculoPage();
    }

    public  void nuevoRegistroVehiculo() throws IOException, InterruptedException {
        waitAndClickElement(nuevoRegistro);
        new RegistroVehiculoPage();
    }

    public void datosPlaca(String placa) throws Exception {
        sendKeysToWebElement(textPlaca,placa);
        //sendKeysToWebElement(textPassword,password);
    }

    public void datosModelo(String modelo) throws Exception {
        sendKeysToWebElement(textModelo,modelo);
    }

    public void datosMarca(String marca) throws Exception {
        clickOnTextFromDropdownList(textBoxMarcas,marca);
    }

    public void datosTipo(String tipo) throws Exception {
        clickOnTextFromDropdownList(textBoxTipos,tipo);
    }

    public void setButtonRegistrar() throws IOException, InterruptedException {
        waitAndClickElement(buttonRegistrar);
        new RegistroVehiculoPage();
    }
    public void mensajeRegistro() throws IOException {
        WebElement mensaje = getDriver().findElement(By.id("swal2-title"));
        WaitUntilWebElementIsVisible(mensaje);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Assert.assertEquals("Vehículo registrado con éxito", mensaje.getText().toLowerCase().replaceAll("[ ()0-9]", ""));
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        new LoginPage();
    }
}
