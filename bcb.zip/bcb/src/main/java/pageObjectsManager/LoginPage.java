package pageObjectsManager;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.io.IOException;

public class LoginPage extends BasePage {
    public @FindBy(xpath = "//input[@id='usuario']") WebElement textUsuario;
    public @FindBy(xpath = "//input[@id='clave']") WebElement textPassword;
    public @FindBy(xpath= "//form[@id='frmLogin']/button") WebElement buttonLogin;

    public LoginPage() throws IOException {
        super();
    }
    public void paginaPrincipal()throws IOException{
        //String url;
        //getDriver().get("Url");
        //new LoginPage();
    }
    public void usuarioContrasenia(String usuario) throws Exception {
        sendKeysToWebElement(textUsuario,usuario);
        //sendKeysToWebElement(textPassword,password);
    }
    public void usuarioPassword(String password) throws Exception {
        //sendKeysToWebElement(textUsuario,usuario);
        sendKeysToWebElement(textPassword,password);
    }
    public void setButtonLogin() throws IOException, InterruptedException {
        waitAndClickElement(buttonLogin);
        new LoginPage();
    }

    public void menuPrincipal() throws IOException {
        WebElement titulo = getDriver().findElement(By.linkText("Vida Informatico"));
        WaitUntilWebElementIsVisible(titulo);
        Assert.assertEquals("vidainformatico", titulo.getText().toLowerCase().replaceAll("[ ()0-9]", ""));
        new LoginPage();
    }
}
