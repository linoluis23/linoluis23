package pageObjectsManager;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import configuracionBrowser.DriverFactory;

import static org.junit.Assert.fail;

public class BasePage extends DriverFactory {
    protected WebDriverWait wait;
    protected JavascriptExecutor jsExecutor;
    private static String screenshotName;

    public BasePage() throws IOException {
        this.wait = new WebDriverWait(driver, 20);
        jsExecutor = ((JavascriptExecutor) driver);
    }

    public static void captureScreenshot() {
    }

    /**********************************************************************************
     **CLICK METHODS
     * @throws IOException
     **********************************************************************************/
    public void waitAndClickElement(WebElement element) throws InterruptedException, IOException {
        boolean hacerClick = false;
        int intentos = 0;
        while (!hacerClick && intentos < 10) {
            try {
                this.wait.until(ExpectedConditions.elementToBeClickable(element)).click();
                System.out.println("Se hizo clic con éxito en el WebElement: " + "<" + element.toString() + ">");
                hacerClick = true;
            } catch (Exception e) {
                System.out.println("No se puede esperar y hacer clic en WebElement, excepción: " + e.getMessage());
                fail("No se puede esperar y hacer clic en WebElement, usando el localizador: " + "<" + element.toString() + ">");
            }
            intentos++;
        }
    }

    public void waitAndClickElementsUsingByLocator(By by) throws InterruptedException {
        boolean hacerClick = false;
        int intentos = 0;
        while (!hacerClick && intentos < 10) {
            try {
                this.wait.until(ExpectedConditions.elementToBeClickable(by)).click();
                System.out.println("Se hizo clic con éxito en el elemento usando el localizador: " + "<" + by.toString() + ">");
                hacerClick = true;
            } catch (Exception e) {
                System.out.println("No se puede esperar y hacer clic en el elemento usando el localizador Por, excepción: " + e.getMessage());
                fail("No se puede esperar y hacer clic en el elemento mediante el localizador Por elemento: " + "<"+ by.toString() + ">");
            }
            intentos++;
        }
    }

    public void clickOnTextFromDropdownList(WebElement list, String textToSearchFor) throws Exception {
        Wait<WebDriver> esperaTiempo = new WebDriverWait(driver, 30);
        try {
            esperaTiempo.until(ExpectedConditions.elementToBeClickable(list)).click();
            list.sendKeys(textToSearchFor);
            list.sendKeys(Keys.ENTER);
            System.out.println("Envió con éxito las siguientes claves: " + textToSearchFor + ", al siguiente WebElement: " + "<" + list.toString() + ">");
        } catch (Exception e) {
            System.out.println("No se pueden enviar las siguientes claves: " + textToSearchFor + ", al siguiente WebElement: " + "<" + list.toString() + ">");
            fail("No se puede seleccionar el texto requerido del menú desplegable, excepción: " + e.getMessage());
        }
    }


    public void clickOnElementUsingCustomTimeout(WebElement locator, WebDriver driver, int timeout) {
        try {
            final WebDriverWait esperaPersonalizada = new WebDriverWait(driver, timeout);
            esperaPersonalizada.until(ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(locator)));
            locator.click();
            System.out.println("Se hizo clic con éxito en WebElement, utilizando el localizador: " + "<" + locator + ">"+ ", utilizando un tiempo de espera personalizado de: " + timeout);
        } catch (Exception e) {
            System.out.println("No se puede hacer clic en el WebElement, usando el localizador: " + "<" + locator + ">" + ", utilizando un tiempo de espera personalizado de: " + timeout);
            fail("No se puede hacer clic en el elemento web, excepción: " + e.getMessage());
        }
    }


    /**********************************************************************************
     **ACTION METHODS
     **********************************************************************************/

    public void actionMoveAndClick(WebElement element) throws Exception {
        Actions ob = new Actions(driver);
        try {
            this.wait.until(ExpectedConditions.elementToBeClickable(element)).isEnabled();
            ob.moveToElement(element).click().build().perform();
            System.out.println("La acción se movió con éxito y se hizo clic en el WebElement, usando el localizador: " + "<" + element.toString() + ">");
        } catch (StaleElementReferenceException elementUpdated) {
            boolean elementPresent = wait.until(ExpectedConditions.elementToBeClickable(element)).isEnabled();
            if (elementPresent) {
                ob.moveToElement(element).click().build().perform();
                System.out.println("(Excepción obsoleta): la acción se movió con éxito y se hizo clic en el WebElement, usando el localizador: " + "<" + element.toString() + ">");
            }
        } catch (Exception e) {
            System.out.println("No se puede mover la acción y hacer clic en el WebElement, usando el localizador: " + "<" + element.toString() + ">");
            fail("No se puede mover la acción y hacer clic en el elemento web, excepción: " + e.getMessage());
        }
    }

    public void actionMoveAndClickByLocator(By element) throws Exception {
        Actions ob = new Actions(driver);
        try {
            boolean elementPresent = wait.until(ExpectedConditions.elementToBeClickable(element)).isEnabled();
            if (elementPresent) {
                WebElement elementToClick = driver.findElement(element);
                ob.moveToElement(elementToClick).click().build().perform();
                System.out.println("La acción se movió y se hizo clic en el siguiente elemento, usando Por localizador: " + "<" + element.toString() + ">");
            }
        } catch (StaleElementReferenceException elementUpdated) {
            WebElement elementToClick = driver.findElement(element);
            ob.moveToElement(elementToClick).click().build().perform();
            System.out.println("Excepción obsoleta): la acción se movió y se hizo clic en el siguiente elemento, usando Por localizador: "+ "<" + element.toString() + ">");
        } catch (Exception e) {
            System.out.println("No se puede mover y hacer clic en el WebElement usando el localizador: " + "<" + element.toString() + ">");
            fail("No se puede mover y hacer clic en el WebElement usando el localizador\n" +
                    "\n, Exception: " + e.getMessage());
        }
    }


    /**********************************************************************************
     **SEND KEYS METHODS /
     **********************************************************************************/
    public void sendKeysToWebElement(WebElement element, String textToSend) throws Exception {
        try {
            this.WaitUntilWebElementIsVisible(element);
            element.clear();
            element.sendKeys(textToSend);
            System.out.println("Envió con éxito las siguientes claves: '" + textToSend + "' al elemento: " + "<"+ element.toString() + ">");
        } catch (Exception e) {
            System.out.println("No se puede localizar WebElement: " + "<" + element.toString() + "> y enviar las siguientes claves: " + textToSend);
            fail("No se pueden enviar claves a WebElement, excepción: " + e.getMessage());
        }
    }


    /**********************************************************************************
     **JS METHODS & JS SCROLL
     **********************************************************************************/
    public void scrollToElementByWebElementLocator(WebElement element) {
        try {
            this.wait.until(ExpectedConditions.visibilityOf(element)).isEnabled();
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);
            ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, -400)");
            System.out.println("Se desplazó con éxito al WebElement, usando el localizador: " + "<" + element.toString() + ">");
        } catch (Exception e) {
            System.out.println("No se puede desplazar al WebElement, usando el localizador: " + "<" + element.toString() + ">");
            fail("No se puede desplazar al WebElement, excepción: " + e.getMessage());
        }
    }

    public void jsPageScroll(int numb1, int numb2) {
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("scroll(" + numb1 + "," + numb2 + ")");
            System.out.println("Desplazado con éxito a la posición correcta! usando localizadores: " + numb1 + ", " + numb2);
        } catch (Exception e) {
            System.out.println("No se puede desplazar al elemento usando localizadores\n" +
                    "\n: " + "<" + numb1 + "> " + " <" + numb2 + ">");
            fail("No se puede desplazar manualmente a WebElement, excepción: " + e.getMessage());
        }
    }

    public void waitAndclickElementUsingJS(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        try {
            wait.until(ExpectedConditions.elementToBeClickable(element));
            js.executeScript("arguments[0].click();", element);
            System.out.println("JS hizo clic con éxito en el siguiente WebElement: " + "<" + element.toString() + ">");
        } catch (StaleElementReferenceException elementUpdated) {
            boolean elementPresent = wait.until(ExpectedConditions.elementToBeClickable(element)).isEnabled();
            if (elementPresent) {
                js.executeScript("arguments[0].click();", elementPresent);
                System.out.println("(Excepción obsoleta) JS hizo clic con éxito en el siguiente WebElement: " + "<" + element.toString() + ">");
            }
        } catch (NoSuchElementException e) {
            System.out.println("No se puede hacer clic en JS en el siguiente WebElement: " + "<" + element.toString() + ">");
            fail("No se puede hacer clic en JS en WebElement\n" +
                    "\n, Exception: " + e.getMessage());
        }
    }

    public void jsClick(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", element);
    }


    /**********************************************************************************
     **WAIT METHODS
     **********************************************************************************/
    public void WaitUntilWebElementIsVisible(WebElement element) {
        try {
            this.wait.until(ExpectedConditions.visibilityOf(element));
            System.out.println("WebElement es visible usando el localizador: " + "<" + element.toString() + ">");
        } catch (Exception e) {
            System.out.println("WebElement NO está visible, usando el localizador: " + "<" + element.toString() + ">");
            fail("WebElement NO es visible, excepción: " + e.getMessage());
        }
    }

    public void WaitUntilWebElementIsVisibleUsingByLocator(By element) {
        try {
            this.wait.until(ExpectedConditions.visibilityOfElementLocated(element));
            System.out.println("El elemento es visible usando Por localizador: " + "<" + element.toString() + ">");
        } catch (Exception e) {
            System.out.println("WebElement NO está visible, usando Por localizador: " + "<" + element.toString() + ">");
            fail("WebElement NO es visible, excepción: " + e.getMessage());
        }
    }

    public boolean isElementClickable(WebElement element) {
        try {
            this.wait.until(ExpectedConditions.elementToBeClickable(element));
            System.out.println("Se puede hacer clic en WebElement usando el localizador: " + "<" + element.toString() + ">");
            return true;
        } catch (Exception e) {
            System.out.println("NO se puede hacer clic en WebElement usando el localizador: " + "<" + element.toString() + ">");
            return false;
        }
    }


    public boolean waitUntilPreLoadElementDissapears(By element) {
        return this.wait.until(ExpectedConditions.invisibilityOfElementLocated(element));
    }


    /**********************************************************************************
     **PAGE METHODS
     **********************************************************************************/
    public BasePage loadUrl(String url) throws Exception {
        driver.get(url);
        return new BasePage();
    }


    public String getCurrentURL() {
        try {
            String url = driver.getCurrentUrl();
            System.out.println("Encontré la siguiente URL: " + url);
            return url;
        } catch (Exception e) {
            System.out.println("No se puede ubicar la URL actual, excepción: " + e.getMessage());
            return e.getMessage();
        }
    }

    public String waitForSpecificPage(String urlToWaitFor) {
        try {
            String url = driver.getCurrentUrl();
            this.wait.until(ExpectedConditions.urlMatches(urlToWaitFor));
            System.out.println("La URL actual era: " + url + ", " + "navegó y esperó la siguiente URL: "+ urlToWaitFor);
            return urlToWaitFor;
        } catch (Exception e) {
            System.out.println("¡Excepción! esperando la URL\n" +
                    "\n: " + urlToWaitFor + ",  Exception: " + e.getMessage());
            return e.getMessage();
        }
    }

    /**********************************************************************************
     **ALERT & POPUPS METHODS
     **********************************************************************************/
    public void closePopups(By locator) throws InterruptedException {
        try {
            List<WebElement> elements = this.wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
            for (WebElement element : elements) {
                if (element.isDisplayed()) {
                    element.click();
                    this.wait.until(ExpectedConditions.invisibilityOfAllElements(elements));
                    System.out.println("La ventana emergente se ha cerrado con éxito!");
                }
            }
        } catch (Exception e) {
            System.out.println("¡Excepción! - ¡No se pudo cerrar la ventana emergente!, Excepto: " + e.toString());
            throw (e);
        }
    }

    public boolean checkPopupIsVisible() {
        try {
            @SuppressWarnings("unused")
            Alert alert = wait.until(ExpectedConditions.alertIsPresent());
            System.out.println("Se ha encontrado una ventana emergente\n" +
                    "\n!");
            return true;
        } catch (Exception e) {
            System.err.println("Se produjo un error mientras esperaba que apareciera la ventana emergente de alerta. " + e.getMessage());
        }
        return false;
    }

    public boolean isAlertPresent() {
        try {
            driver.switchTo().alert();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public void closeAlertPopupBox() throws AWTException, InterruptedException {
        try {
            Alert alert = this.wait.until(ExpectedConditions.alertIsPresent());
            alert.accept();
        } catch (UnhandledAlertException f) {
            Alert alert = driver.switchTo().alert();
            alert.accept();
        } catch (Exception e) {
            System.out.println("No se puede cerrar la ventana emergente");
            fail("No se puede cerrar la ventana emergente, excepción: " + e.getMessage());
        }
    }

    /***EXTENT REPORT****************************************************************/
    public static String returnDateStamp(String fileExtension) {
        Date d = new Date();
        String date = d.toString().replace(":", "_").replace(" ", "_") + fileExtension;
        return date;
    }

    /*public static void captureScreenshot() throws IOException, InterruptedException {
        File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

        screenshotName = returnDateStamp(".jpg");

        FileUtils.copyFile(srcFile, new File(System.getProperty("user.dir") + "\\output\\imgs\\" + screenshotName));

        Reporter.
                addStepLog("Tomando una captura de pantalla!");
        Reporter.addStepLog("<br>");
        Reporter.addStepLog("<a target=\"_blank\", href="+ returnScreenshotName() + "><img src="+ returnScreenshotName()+ " height=200 width=300></img></a>");
    }
*/
    public static String returnScreenshotName() {
        return (System.getProperty("user.dir") + "\\output\\imgs\\" + screenshotName).toString();
    }

    private static void copyFileUsingStream(File source, File dest) throws IOException {
        InputStream is = null;
        OutputStream os = null;

        try {
            is = new FileInputStream(source);
            os = new FileOutputStream(dest);
            byte[] buffer = new byte[960];
            int length;

            while((length = is.read(buffer)) > 0) {
                os.write(buffer, 0, length);
            }

        } finally {
            assert is != null;
            is.close();
            assert os != null;
            os.close();
        }
    }

    public static void copyLatestExtentReport() throws IOException {
        Date d = new Date();
        String date = d.toString().replace(":", "_").replace(" ", "_");
        File source = new File(System.getProperty("user.dir") + "\\output\\report.html");
        File dest = new File(System.getProperty("user.dir") + "\\output\\" + date.toString() + ".html");
        copyFileUsingStream(source, dest);
    }
}