package runners;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;
import static io.cucumber.junit.CucumberOptions.SnippetType.CAMELCASE;

@RunWith(Cucumber.class)

@CucumberOptions(features = "src/test/java/features/" ,
        glue = "stepDefinitions",
        monochrome = true,
        snippets = CAMELCASE,
        tags = "@Login or @Vehiculo",
        plugin= {"pretty", "html:target/cucumber.html", "json:target/cucumber.json",
               "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
               "rerun:target/failed_scenarios.txt"}
)


public class JunitTestRunner {

}