class LoginPage {
  visit() {
    cy.visit('https://www.saucedemo.com/') // Cambia al path real de tu app
  }

  fillUsername(username) {
    cy.get('#user-name').type(username)
  }

  fillPassword(password) {
    cy.get('#password').type(password)
  }

  submit() {
    cy.get('#login-button').click()
  }
}

export default LoginPage