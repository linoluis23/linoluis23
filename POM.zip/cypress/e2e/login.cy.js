describe('Login con POM + Commands', () => {
  it.only('Debe iniciar sesión exitosamente', () => {
    cy.login('standard_user', 'secret_sauce')
    cy.url().should('include', '/inventory') // Cambia según tu app
    cy.contains('Products') // Verifica que el login fue exitoso
  })
})

/*
import LoginPage from '../pages/loginPage';

const loginPage = new LoginPage();

describe('Pruebas de Login', () => {
  beforeEach(() => {
    loginPage.visit();
  });

  it('Login con credenciales válidas', () => {
    cy.fixture('credenciales').then((data) => {
      const { username, password } = data.usuarioValido;
      loginPage.login(username, password);

      // Aquí puedes verificar si el login fue exitoso
      //cy.url().should('include', '/dashboard'); // Ejemplo
          cy.url().should('include', '/inventory') // Cambia según tu app
    cy.contains('Products') // Verifica que el login fue exitoso
    });
  });

  it('Login con credenciales inválidas', () => {
    cy.fixture('credenciales').then((data) => {
      const { username, password } = data.usuarioInvalido;
      loginPage.login(username, password);

      // Verifica que se muestre un mensaje de error
      cy.get('.error-message').should('be.visible');
    });
  });
});

*/