import LoginPage from '../pageObjects/LoginPage'

Cypress.Commands.add('login', (usuario, contraseña) => {
  const loginPage = new LoginPage()
  loginPage.visit()
  loginPage.fillUsername(usuario)
  loginPage.fillPassword(contraseña)
  loginPage.submit()
})