import LoginPage from '../pageObject/loginPage';

const loginPage = new LoginPage();

describe('Pruebas de Login', () => {
  beforeEach(() => {
    loginPage.visit();
  });

  it.only('Login con credenciales válidas', () => {
    cy.fixture('credenciales').then((data) => {
      const { username, password } = data.usuarioValido;
      loginPage.login(username, password);

      // Aquí puedes verificar si el login fue exitoso
      cy.url().should('include', '/inventory') // verificar la ruta posterior login
    cy.contains('Products') // Verifica que el login fue exitoso
    });
  });

  it.only('Login con credenciales inválidas', () => {
    cy.fixture('credenciales').then((data) => {
      const { username, password } = data.usuarioInvalido;
      loginPage.login(username, password);

      // Verifica que se muestre un mensaje de error
      cy.get('[data-test="error"]').should('be.visible');
    });
  });
});
