class LoginPage {
  visit() {
    cy.visit(Cypress.config('baseUrl')); // llama a URL de cypress.config
  }

  login(username, password) {
    cy.login(username, password); // Llama al comando definido
  }
}

export default LoginPage;